include('MC15JobOptions/MadGraphControl_SimplifiedModel_GG_RPV.py')
